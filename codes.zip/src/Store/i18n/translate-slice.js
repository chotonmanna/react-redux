import { createSlice } from '@reduxjs/toolkit';
import { config } from './lang-config';
import { persistReducer } from 'redux-persist';
import { CookieStorage } from 'redux-persist-cookie-storage';
import Cookies from 'cookies-js';

const initialState = {
  currentLanguage: config.default
}

const translateSlice = createSlice({
  name: 'i18n',
  initialState,
  reducers: {
    setCurrentLanguage(state, action) {
      state.currentLanguage = action.payload;
    }
  }
});

export const translateActions = translateSlice.actions;

const reducer = persistReducer({
  key: 'i18n-persist',
  storage: new CookieStorage(Cookies)
}, translateSlice.reducer);

export default reducer;
