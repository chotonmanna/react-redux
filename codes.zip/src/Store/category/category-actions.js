import axios from "axios";
import { notificationActions } from '../notification';
import { categoryActions } from './category-slice';
import { getConfig } from '../../Config';

export const getAllList = () => {
  return async (dispatch) => {
    dispatch(notificationActions.showSpinner());
    try {
      const response = await axios.get(`${getConfig().baseUrl}/category/getalllist`);
      dispatch(notificationActions.hideSpinner());
      if (response.data) {
        dispatch(categoryActions.updateList(response.data.data));
      }
    } catch (error) {
      const message = error?.response?.data?.msg || 'Please try again..';
      dispatch(notificationActions.showNotification({ type: 'error', message }));
      dispatch(notificationActions.hideSpinner());
    }
  }
}

export const updateData = (data, cb) => {
  return async (dispatch) => {
    dispatch(notificationActions.showSpinner());
    try {
      let response = null;
      if (data?.id) {
        response = await axios.put(`${getConfig().baseUrl}/category/update`, data);
      } else {
        response = await axios.post(`${getConfig().baseUrl}/category/addnew`, data);
      }

      dispatch(notificationActions.hideSpinner());
      dispatch(notificationActions.showNotification({ type: 'success', message: response.data.msg }));
      if (response.data) {
        dispatch(categoryActions.updateList(response.data.data));
        cb();
      }
    } catch (error) {
      const message = error?.response?.data?.msg || 'Please try again..';
      dispatch(notificationActions.showNotification({ type: 'error', message }));
      dispatch(notificationActions.hideSpinner());
    }
  }
}
