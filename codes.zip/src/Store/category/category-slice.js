import { createSlice } from '@reduxjs/toolkit';
import { persistReducer } from 'redux-persist';
import storageSession from 'redux-persist/lib/storage/session';

const categorySlice = createSlice({
  name: 'category',
  initialState: {
    list: [],
    data: null
  },
  reducers: {
    updateList(state, action) {
      state.list = action.payload;
    },
    setDataAsEdiatble(state, action) {
      state.data = action.payload;
    },
    resetEdiatbleData(state) {
      state.data = null;
    }
  }
});

const reducer = persistReducer({
  key: 'category-persist',
  storage: storageSession,
  blacklist: ['list']
}, categorySlice.reducer);

export const categoryActions = categorySlice.actions;
export default reducer;