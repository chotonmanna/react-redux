import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  type: null,
  message: null,
  showSpinner: false
};

const notificationSlice = createSlice({
  name: 'notification',
  initialState,
  reducers: {
    showNotification(state, action) {
      state.type = action.payload.type;
      state.message = action.payload.message;
    },
    hideNotification(state) {
      state.type = null;
      state.message = null;
    },
    showSpinner(state) {
      state.showSpinner = true;
    },
    hideSpinner(state) {
      state.showSpinner = false;
    },
  }
});

export const notificationActions = notificationSlice.actions;

export default notificationSlice;
