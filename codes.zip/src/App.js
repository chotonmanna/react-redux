import './App.css';
import GlobalMessage from './Components/Common/GobalMessage';
import Spinner from './Components/Common/Spinner';
import RecatAppBar from './Components/Common/AppBar';
import AppRouter from './Router';
import Copyright from './Components/Common/Copyright';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { BrowserRouter } from 'react-router-dom';

function App() {
  const theme = createTheme();
  return (
    <BrowserRouter>
      <ThemeProvider theme={theme}>
        <Container component="main" maxWidth="md">
          <RecatAppBar />
          <Spinner />
          <GlobalMessage />
          <AppRouter />
          <Copyright sx={{ mt: 5 }} />
        </Container>
      </ThemeProvider>
    </BrowserRouter>
  );
}

export default App;
