import { Box, Avatar, Typography, TextField, Grid, FormControl, FormLabel, FormControlLabel, Button, Checkbox } from '@mui/material';
import { useEffect } from 'react';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { Link } from 'react-router-dom';
import { useCookie } from '../../Hooks/useCookie';
import { useSelector, useDispatch } from 'react-redux';
import { submitLoginData } from '../../Store/login/login-actions';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [ setRememberMeUserCookieValue, rememberMeUserCookieValue ] = useCookie('rememberMeUser');
  const authUserData = useSelector(state => state.login.authUserData);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const initialValues = {
    username: rememberMeUserCookieValue?.username || '',
    password: rememberMeUserCookieValue?.password || '',
    rememberMe: rememberMeUserCookieValue?.rememberMe || false
  };
  const validationSchema = Yup.object().shape({
    username: Yup.string().required('This field is required'),
    password: Yup.string().required('This field is required')
  });

  useEffect(() => {
    if (authUserData) {
      navigate('/profile');
    }
  }, [authUserData, navigate]);

  const onSubmit = async (values) => {
    const response = await dispatch(submitLoginData(values));
    if (!response?.error && response?.payload) {
      setRememberMeUserCookieValue(values.rememberMe ? JSON.stringify(values) : null);
    }
  }

  return (
    <Box sx={{ marginTop: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}></Avatar>
      <Typography variant="h4">Sign In</Typography>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ values, errors, touched, handleBlur, handleChange, handleSubmit }) => (
          <Box sx={{ marginTop: 5 }}>
            <form onSubmit={handleSubmit} noValidate>
              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <TextField
                    name="username"
                    required
                    fullWidth
                    id="username"
                    label="Username"
                    value={values.username}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    error={!!(touched.username && errors.username)}
                    helperText={(touched.username && errors.username) && errors.username}
                  />
                </Grid>
                <Grid item xs={12} md={12}>
                  <TextField
                    type="password"
                    name="password"
                    required
                    fullWidth
                    id="password"
                    label="Password"
                    value={values.password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    error={!!(touched.password && errors.password)}
                    helperText={(touched.password && errors.password) && errors.password}
                  />
                </Grid>
                <Grid item xs={12} md={12}>
                  <FormControl>
                    <FormLabel>Remember Me</FormLabel>
                    <FormControlLabel label="Remember Me" control={
                      <Checkbox checked={values.rememberMe} name="rememberMe" onChange={handleChange} />
                    } />
                  </FormControl>
                </Grid>
                <Grid container display="flex" flexDirection="column" alignItems="end">
                  <Grid item>
                    <Button type="submit" variant="contained" sx={{ mt: 3, mb: 2 }}>Submit</Button>
                  </Grid>
                  <Grid item>
                    <Link to="/registration" variant="body2">
                      New User? Sign up
                    </Link>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </Box>
        )}
      </Formik>
    </Box>
  );
}

export default Login;