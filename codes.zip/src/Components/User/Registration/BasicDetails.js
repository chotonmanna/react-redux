import { Radio, RadioGroup, FormControlLabel, FormControl, FormLabel, TextField, Grid, Box, FormHelperText }
  from '@mui/material';
import { Formik } from 'formik';
import { useNavigate, useOutletContext } from 'react-router-dom';
import * as Yup from 'yup';
import { useSelector } from 'react-redux';
import { StepperButtons } from '../../Common/FormStepper/StepperButtons';
import { Translate } from '../../Common/Translate';

function BasicDetails() {
  const { onInputChangeHandler } = useOutletContext();
  const user = useSelector(state => state.registration.data);

  const navigate = useNavigate();
  const initialValues = {
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    mobile: user?.mobile || '',
    dob: user?.dob || '',
    gender: user?.gender || ''
  };
  const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/

  const validationSchema = Yup.object().shape({
    firstName: Yup.string().required('This field is required'),
    email: Yup.string()
      .required('This field is required')
      .email('Invalid email'),
    dob: Yup.string().required('This field is required'),
    mobile: Yup.string().required('This field is required').matches(phoneRegExp, 'Phone number is not valid'),
    gender: Yup.string().required('This field is required')
  });

  const onSubmit = () => {
    navigate('/registration/address-details');
  }

  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ values, handleSubmit, handleChange, errors, touched }) => (
        <Box sx={{ mt: 5 }}>
          <form onSubmit={handleSubmit} noValidate>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="firstName"
                  required
                  fullWidth
                  id="firstName"
                  label={<Translate labelKey="registration.basic-details.firstname" />}
                  value={values.firstName}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.firstName && errors.firstName)}
                  helperText={(touched.firstName && errors.firstName) && errors.firstName}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  id="lastName"
                  label={<Translate labelKey="registration.basic-details.lastname" />}
                  name="lastName"
                  value={values.lastName}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="email"
                  label={<Translate labelKey="registration.basic-details.email" />}
                  name="email"
                  autoComplete="email"
                  value={values.email}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.email && errors.email)}
                  helperText={(touched.email && errors.email) && errors.email}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  name="mobile"
                  label={<Translate labelKey="registration.basic-details.mobile" />}
                  id="mobile"
                  value={values.mobile}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.mobile && errors.mobile)}
                  helperText={(touched.mobile && errors.mobile) && errors.mobile}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  name="dob"
                  label={<Translate labelKey="registration.basic-details.dob" />}
                  id="dob"
                  value={values.dob}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.dob && errors.dob)}
                  helperText={(touched.dob && errors.dob) && errors.dob}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl
                  error={!!(touched.gender && errors.gender)}>
                  <FormLabel>{<Translate labelKey="registration.basic-details.gender.title" />}</FormLabel>
                  <RadioGroup row value={values.gender} name="gender" onChange={(e) => onInputChangeHandler(e, handleChange)}>
                    <FormControlLabel label={<Translate labelKey="registration.basic-details.gender.M" />} value="M" control={<Radio />} />
                    <FormControlLabel label={<Translate labelKey="registration.basic-details.gender.F" />} value="F" control={<Radio />} />
                  </RadioGroup>
                  <FormHelperText>{(touched.gender && errors.gender) && errors.gender}</FormHelperText>
                </FormControl>
              </Grid>
              <StepperButtons id="registration" />
            </Grid>
          </form>
        </Box>
      )}
    </Formik>
  );
}

export default BasicDetails;