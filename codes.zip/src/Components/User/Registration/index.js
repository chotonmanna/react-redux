export { default as BasicDetails } from './BasicDetails';
export { default as AddressDetails } from './AddressDetails';
export { default as LoginDetails } from './LoginDetails';
export { default as Registration } from './Registration';