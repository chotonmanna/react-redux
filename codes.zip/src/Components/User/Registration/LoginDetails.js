import { TextField, Grid, Box, FormControlLabel, Checkbox, FormHelperText, FormControl, FormLabel } from '@mui/material';
import { Formik } from 'formik';
import { useOutletContext } from 'react-router-dom';
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { submitUserData } from '../../../Store/registration/registration-actions';
import { StepperButtons } from '../../../Components/Common/FormStepper/StepperButtons'
import { Translate } from '../../Common/Translate';

function LoginDetails() {
  const { onInputChangeHandler } = useOutletContext();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector(state => state.registration.data);
  const initialValues = {
    username: user?.username || '',
    password: user?.password || '',
    confirmPassword: user?.confirmPassword || '',
    termsCondition: user?.termsCondition || false
  };

  const validationSchema = Yup.object().shape({
    username: Yup.string().required('This field is required').min('6', 'Minimum 6 chars length'),
    password: Yup.string().required('This field is required').min('6', 'Minimum 6 chars length'),
    confirmPassword: Yup.string()
      .required('This field is required')
      .oneOf([Yup.ref('password')], 'Confirm password must match passord'),
    termsCondition: Yup.boolean().isTrue('Please select terms condition')
  });

  const onSubmit = async () => {
    const response = await dispatch(submitUserData(user));
    if (!response?.error) {
      navigate('/registration');
    }
  }

  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ values, handleChange, handleSubmit, errors, touched }) => (
        <Box sx={{ marginTop: 5 }}>
          <form onSubmit={handleSubmit} noValidate>
            <Grid container spacing={2}>
              <Grid item xs={12} md={12}>
                <TextField
                  name="username"
                  required
                  fullWidth
                  id="username"
                  label={<Translate labelKey="registration.login-details.username" />}
                  value={values.username}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.username && errors.username)}
                  helperText={(touched.username && errors.username) && errors.username}
                />
              </Grid>
              <Grid item xs={12} md={12}>
                <TextField
                  type="password"
                  name="password"
                  required
                  fullWidth
                  id="password"
                  label={<Translate labelKey="registration.login-details.password" />}
                  value={values.password}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.password && errors.password)}
                  helperText={(touched.password && errors.password) && errors.password}
                />
              </Grid>
              <Grid item xs={12} md={12}>
                <TextField
                  type="password"
                  name="confirmPassword"
                  required
                  fullWidth
                  id="confirmPassword"
                  label={<Translate labelKey="registration.login-details.conf-password" />}
                  value={values.confirmPassword}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.confirmPassword && errors.confirmPassword)}
                  helperText={(touched.confirmPassword && errors.confirmPassword) && errors.confirmPassword}
                />
              </Grid>
              <Grid item xs={12} md={12}>
                <FormControl error={!!(touched.termsCondition && errors.termsCondition)}>
                  <FormLabel><Translate labelKey="registration.login-details.terms-conditions" /></FormLabel>
                  <FormControlLabel label={<Translate labelKey="registration.login-details.terms-conditions" />} control={
                    <Checkbox checked={values.termsCondition} name="termsCondition" onChange={handleChange} />
                  } />
                  <FormHelperText>{(touched.termsCondition && errors.termsCondition) && errors.termsCondition}</FormHelperText>
                </FormControl>
              </Grid>

              <StepperButtons id="registration" />

            </Grid>
          </form>
        </Box>
      )}
    </Formik>
  );
}

export default LoginDetails;