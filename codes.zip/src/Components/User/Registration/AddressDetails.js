import { TextField, Grid, Box } from '@mui/material';
import { Formik } from 'formik';
import { useNavigate, useOutletContext } from 'react-router-dom';
import * as Yup from 'yup';
import { useSelector } from 'react-redux';
import { StepperButtons } from '../../../Components/Common/FormStepper/StepperButtons';
import { Translate } from '../../Common/Translate';

function AddressDetails() {
  const { onInputChangeHandler } = useOutletContext();
  const navigate = useNavigate();
  const user = useSelector(state => state.registration.data);
  const initialValues = {
    houseNumber: user?.houseNumber || '',
    land1: user?.land1 || '',
    land2: user?.land2 || '',
    zipcode: user?.zipcode || '',
    city: user?.city || '',
    state: user?.state || '',
    country: user?.country || ''
  };

  const validationSchema = Yup.object().shape({
    houseNumber: Yup.string().required('This field is required'),
    land1: Yup.string().required('This field is required'),
    zipcode: Yup.string().required('This field is required')
      .min(6, 'Must be 6 chars length')
      .max(6, 'Must be 6 chars length')
      .matches(/[0-9]{6}/, 'Not a valid zipcode'),
    city: Yup.string().required('This field is required'),
    state: Yup.string().required('This field is required'),
    country: Yup.string().required('This field is required')
  });

  const onSubmit = () => {
    navigate('/registration/login-details');
  }

  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ values, handleChange, handleSubmit, errors, touched, isSubmitting }) => (
        <Box sx={{ mt: 5 }}>
          <form onSubmit={handleSubmit} noValidate>
            <Grid container spacing={2}>
              <Grid item xs={6} sm={6}>
                <TextField
                  name="houseNumber"
                  required
                  fullWidth
                  id="houseNumber"
                  label={<Translate labelKey="registration.address-details.house-number" />}
                  value={values.houseNumber}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.houseNumber && errors.houseNumber)}
                  helperText={(touched.houseNumber && errors.houseNumber) && errors.houseNumber}
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  name="land1"
                  required
                  fullWidth
                  id="land1"
                  label={<Translate labelKey="registration.address-details.land1" />}
                  value={values.land1}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.land1 && errors.land1)}
                  helperText={(touched.land1 && errors.land1) && errors.land1}
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  name="land2"
                  fullWidth
                  id="land2"
                  label={<Translate labelKey="registration.address-details.land2" />}
                  value={values.land2}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="zipcode"
                  required
                  fullWidth
                  id="zipcode"
                  label={<Translate labelKey="registration.address-details.zip" />}
                  value={values.zipcode}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.zipcode && errors.zipcode)}
                  helperText={(touched.zipcode && errors.zipcode) && errors.zipcode}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="city"
                  required
                  fullWidth
                  id="city"
                  label={<Translate labelKey="registration.address-details.city" />}
                  value={values.city}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.city && errors.city)}
                  helperText={(touched.city && errors.city) && errors.city}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="state"
                  required
                  fullWidth
                  id="state"
                  label={<Translate labelKey="registration.address-details.state" />}
                  value={values.state}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.state && errors.state)}
                  helperText={(touched.state && errors.state) && errors.state}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="country"
                  required
                  fullWidth
                  id="country"
                  label={<Translate labelKey="registration.address-details.country" />}
                  value={values.country}
                  onChange={(e) => onInputChangeHandler(e, handleChange)}
                  error={!!(touched.country && errors.country)}
                  helperText={(touched.country && errors.country) && errors.country}
                />
              </Grid>

              <StepperButtons id="registration" />
            </Grid>
          </form>
        </Box>
      )}
    </Formik>
  );
}

export default AddressDetails;