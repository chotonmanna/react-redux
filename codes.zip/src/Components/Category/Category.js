import {
  Box, Typography, Grid, TextField, FormControlLabel, FormLabel,
  RadioGroup, Radio, Button, MenuItem, FormHelperText
} from '@mui/material';
import { Fragment, useMemo } from 'react';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Formik } from 'formik';
import CategoryList from './List';
import { useSelector, useDispatch } from 'react-redux';
import { updateData } from '../../Store/category/category-actions';
import * as Yup from 'yup';
import './Category.css';
import { categoryActions } from '../../Store/category/category-slice';

function Category() {
  const list = useSelector(state => state.category.list);
  const dataAsEditable = useSelector(state => state.category.data);
  const dispatch = useDispatch();
  const initialValues = {
    parent: dataAsEditable?.parent || '0',
    name: dataAsEditable?.name || '',
    status: dataAsEditable?.status || '1',
    type: dataAsEditable?.type || '0',
    isNew: dataAsEditable?.isNew || '0',
    isSale: dataAsEditable?.isSale || '0'
  };

  const onSubmit = (values, { resetForm }) => {
    const updatedValue = { ...dataAsEditable, ...values };
    dispatch(updateData(updatedValue, () => {
      handleResetForm(resetForm);
    }));
  }

  const handleResetForm = (resetForm) => {
    resetForm();
    dispatch(categoryActions.resetEdiatbleData());
  }

  const validationSchema = Yup.object().shape({
    name: Yup.string().required('This field is required'),
    type: Yup.string().oneOf(['1', '2'], 'This field is required')
  });

  const modifiedList = useMemo(() => {
    const arr = [];
    const makeArray = (list, spaces = 0) => {
      list.forEach(row => {
        spaces = row?.parent === '0' ? 0 : spaces;
        arr.push({ ...row, spaces });
        if (row?.children && row.children.length) {
          makeArray(row?.children, spaces + 4);
        }
      });
    }
    makeArray(list);

    return arr;
  }, [list]);

  return (
    <Box sx={{ marginTop: 2 }}>
      <Typography variant="h4">Manage Menus</Typography>

      <Grid container display="flex" flexDirection="row">
        <Grid sx={{ width: '50%' }} item>
          <Formik
            enableReinitialize={true}
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {({ values, errors, touched, handleChange, handleBlur, handleSubmit, resetForm }) => (
              <Box sx={{ marginTop: 2 }}>
                <form onSubmit={handleSubmit} noValidate>
                  <Grid container>
                    <Grid sx={{ mt: 2 }} item xs={10} md={10}>
                      <FormControl variant="standard" fullWidth>
                        <InputLabel id="parent">Select Menu</InputLabel>
                        <Select name="parent" id="parent" value={values.parent} onChange={handleChange}>
                          <MenuItem value={0}><em>Root</em></MenuItem>
                          {
                            modifiedList.map((row, key) =>
                              <MenuItem key={key} value={row.id}>
                                {Array(row.spaces).fill().map((r, k) => <Fragment key={k}>&nbsp;</Fragment>)}
                                {row.name}
                              </MenuItem>)
                          }
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid sx={{ mt: 2 }} item xs={10} md={10}>
                      <FormControl variant="standard" fullWidth error={!!(touched.type && errors.type)}>
                        <InputLabel id="type">Select Type</InputLabel>
                        <Select name="type" id="type" value={values.type} onChange={handleChange}>
                          <MenuItem value="0">---- Select Type -----</MenuItem>
                          <MenuItem value="1">Product Page</MenuItem>
                          <MenuItem value="2">Static Content Page</MenuItem>
                        </Select>
                        <FormHelperText>{(touched.type && errors.type) && errors.type}</FormHelperText>
                      </FormControl>
                    </Grid>
                    <Grid item xs={10} md={10}>
                      <TextField
                        variant="standard"
                        name="name"
                        required
                        fullWidth
                        id="name"
                        label="Menu Name"
                        value={values.name}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={!!(touched.name && errors.name)}
                        helperText={(touched.name && errors.name) && errors.name}
                      />
                    </Grid>

                    <Grid sx={{ mt: 2 }} item xs={12} md={6}>
                      <FormControl>
                        <FormLabel>Is New ?</FormLabel>
                        <RadioGroup row name="isNew" value={values.isNew} onChange={handleChange}>
                          <FormControlLabel label="Yes" value='1' control={<Radio />} />
                          <FormControlLabel label="No" value='0' control={<Radio />} />
                        </RadioGroup>
                      </FormControl>
                    </Grid>

                    <Grid sx={{ mt: 2 }} item xs={12} md={5}>
                      <FormControl>
                        <FormLabel>Is Sale ?</FormLabel>
                        <RadioGroup row name="isSale" value={values.isSale} onChange={handleChange}>
                          <FormControlLabel label="Yes" value='1' control={<Radio />} />
                          <FormControlLabel label="No" value='0' control={<Radio />} />
                        </RadioGroup>
                      </FormControl>
                    </Grid>

                    <Grid sx={{ mt: 2 }} item xs={12} md={12}>
                      <FormControl>
                        <FormLabel>Status</FormLabel>
                        <RadioGroup row name="status" value={values.status} onChange={handleChange}>
                          <FormControlLabel label="Active" value='1' control={<Radio />} />
                          <FormControlLabel label="Inactive" value='0' control={<Radio />} />
                        </RadioGroup>
                      </FormControl>
                    </Grid>

                    <Grid sx={{ mt: 2 }} item xs={12} md={12} display="flex" flexDirection="row" justifyContent="flex-start" alignItems="center">
                      <Grid item sx={{ mr: 2 }}>
                        <Button onClick={() => handleResetForm(resetForm)} type="button" variant="contained" color="warning" sx={{ mb: 2 }}>Cancel</Button>
                      </Grid>
                      <Grid item>
                        <Button type="submit" variant="contained" color="primary" sx={{ mb: 2 }}>Submit</Button>
                      </Grid>
                    </Grid>
                  </Grid>

                </form>
              </Box>
            )}
          </Formik>
        </Grid>
        <Grid sx={{ width: '50%' }} item>
          <CategoryList />
        </Grid>
      </Grid>
    </Box>
  );
}

export default Category;
