import {
  Box
} from '@mui/material';

function Others() {
  return (
    <Box sx={{ marginTop: 2 }}>Others</Box>
  );
}

export default Others; 