import {
  Box
} from '@mui/material';

function Status() {
  return (
    <Box sx={{ marginTop: 2 }}>Status</Box>
  );
}

export default Status; 