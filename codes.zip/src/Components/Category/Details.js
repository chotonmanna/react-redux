import {
  Box
} from '@mui/material';

function Details() {
  return (
    <Box sx={{ marginTop: 2 }}>Details</Box>
  );
}

export default Details; 