import {
  Box
} from '@mui/material';

function Type() {
  return (
    <Box sx={{ marginTop: 2 }}>Type</Box>
  );
}

export default Type; 