import { Stepper, Box, Step, StepLabel } from '@mui/material';
import { useLocation } from 'react-router-dom';
import { useMemo } from 'react';
import { getCurrentRoute } from '../../../Config';
import { Translate } from '../Translate';

export default function FormStepper(props) {
  const location = useLocation();
  const { activeStep, getStep } = useMemo(() => {
    return getCurrentRoute(props.id, location.pathname)
  }, [location, props]);

  return (
    <Box sx={{ width: '100%' }}>
      <Stepper activeStep={activeStep}>
        {getStep.children.map((step, index) =>
          <Step key={index}><StepLabel>{<Translate labelKey={step.label} />}</StepLabel></Step>
        )}
      </Stepper>
      {props.children}
    </Box>
  );
}
