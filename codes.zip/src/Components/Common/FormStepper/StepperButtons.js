import { Button, Grid } from '@mui/material';
import { useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { getCurrentRoute } from '../../../Config';

export const StepperButtons = (props) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { activeStep, getStep } = useMemo(() => getCurrentRoute(props.id, location.pathname), [location, props]);
  const isStartStep = useMemo(() => (activeStep === 0), [activeStep]);
  const isEndStep = useMemo(() => (activeStep === (getStep.children.length - 1)), [activeStep, getStep]);
  const navigateBack = () => {
    navigate(`/${getStep.path}/${getStep.children[activeStep - 1].path}`);
  }

  return (
    <Grid container display="flex" flexDirection="row" justifyContent="space-between" alignItems="center">
      <Grid item>
        {!isStartStep && <Button type="button" onClick={navigateBack} variant="text" sx={{ mt: 3, mb: 2 }}>Back</Button>}
      </Grid>
      <Grid item>
        <Button type="submit" variant="contained" sx={{ mt: 3, mb: 2 }}>
          {isEndStep ? 'Submit' : 'Next'}
        </Button>
      </Grid>
    </Grid>
  );
}
