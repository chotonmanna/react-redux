import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import { useSelector, useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { notificationActions } from '../../Store/notification';

export default function GlobalMessage() {
  const { type, message } = useSelector(state => state.notification);
  const dispatch = useDispatch();

  useEffect(() => {
    if (type) {
      setTimeout(() => {
        dispatch(notificationActions.hideNotification());
      }, 4000);
    }
  }, [type, dispatch]);

  return (
    (type && message) &&
    <Snackbar
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      open={true}
      key="top-right">
      <Alert severity={type} variant="filled">{message}</Alert>
    </Snackbar>
  );
}
