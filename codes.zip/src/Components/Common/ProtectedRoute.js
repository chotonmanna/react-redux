import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

function ProtectedRoutes({ children }) {
  const authUserData = useSelector(state => state.login.authUserData);

  if (!authUserData) {
    return <Navigate to="/login" />;
  }

  return children;
}

export default ProtectedRoutes;
