import * as React from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import { useSelector } from 'react-redux';

export default function Spinner() {
  const showSpinner = useSelector(state => state.notification.showSpinner);

  return (
    showSpinner &&
    <Box sx={{
      position: 'absolute',
      height: '100%',
      width: '100%',
      top: '0px',
      left: '0px',
      display: 'flex',
      textAlign: 'center',
      fontSize: '1.2em',
      color: '#FFF',
      background: 'rgba(0,0,0,0.7)',
      zIndex: '800',
      transition: 'opacity 500ms ease-in',
      opacity: 1
    }}>
      <div style={{ margin: 'auto' }}>
        <CircularProgress color="secondary" />
      </div>
    </Box>
  );
}
