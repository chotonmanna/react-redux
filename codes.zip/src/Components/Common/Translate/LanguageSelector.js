import { useDispatch, useSelector } from 'react-redux';
import { config } from '../../../Store/i18n/lang-config';
import { translateActions } from '../../../Store/i18n/translate-slice';

function LanguageSelector() {
  const currentLanguage = useSelector(state => state.i18n.currentLanguage);
  const dispatch = useDispatch();
  const onLangChangeHandler = (e) => {
    dispatch(translateActions.setCurrentLanguage(e.target.value));
  }

  return (
    <select value={currentLanguage} onChange={onLangChangeHandler}
      style={{ border: 0, color: '#FFF', backgroundColor: '#1976d2' }}>
      {config.languages.map((lang, i) =>
        <option key={i} value={lang.id}>
          {lang.label}
        </option>
      )}
    </select>
  );
}

export default LanguageSelector; 