function PageNotFound() {
  return (
    <h1>
      404 Page Not Found
    </h1>
  );
}

export default PageNotFound;