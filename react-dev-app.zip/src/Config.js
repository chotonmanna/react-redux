import { steps } from './Components/Common/FormStepper/StepConfig';

export const getConfig = () => {
  return {
    //baseUrl: 'http://35.78.74.77:3001'
    baseUrl: 'http://localhost:3001'
  }
}

export const getCurrentRoute = (currentRouteId, currentPath) => {
  const { children, path } = steps.find(step => step.id === currentRouteId);
  const stepNumber = children.findIndex(step => currentPath.includes(step.path));
  const isStartStep = stepNumber === 0;
  const isEndStep = stepNumber === (children.length - 1);

  return {
    children,
    stepNumber,
    isStartStep,
    isEndStep,
    prevPath: (!isStartStep && stepNumber > -1) ? `/${path}/${children[stepNumber - 1].path}` : null,
    nextPath: (!isEndStep && stepNumber > -1) ? `/${path}/${children[stepNumber + 1].path}` : null
  }
}

