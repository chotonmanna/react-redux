import { Routes, Route, Navigate } from "react-router-dom";
import Registration from './Components/User/Registration/Registration';
import Login from './Components/User/Login';
import PageNotFound from './NotFound';
import Profile from './Components/User/Profile';
import ProtectedRoutes from './Components/Common/ProtectedRoute';
import Category from './Components/Category/Category';
import Parameters from './Components/Parameters/Parameters';
import { steps } from './Components/Common/FormStepper/StepConfig';

function AppRouter() {
  const loadChildRoutes = (id) => {
    const { children, path } = steps.find(step => step.id === id);
    return (
      <>
        <Route index element={<Navigate to={`/${path}/${children[0].path}`} />} />
        {children.map((child, key) =>
          <Route
            key={key}
            path={child.path}
            element={child.component}
          />
        )}
      </>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/registration/basic-details" />} />
      <Route path="registration" element={<Registration />}>
        {loadChildRoutes('registration')}
      </Route>
      <Route path="login" element={<Login />} />
      <Route path="profile" element={
        <ProtectedRoutes>
          <Profile />
        </ProtectedRoutes>
      } />
      <Route path="category" element={
        <ProtectedRoutes>
          <Category />
        </ProtectedRoutes>
      }>
        {loadChildRoutes('category')}
      </Route>
      <Route path="manage-parameters" element={
        <ProtectedRoutes>
          <Parameters />
        </ProtectedRoutes>
      } />
      <Route path="manage-products" element={
        <ProtectedRoutes>
          <Profile />
        </ProtectedRoutes>
      } />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}

export default AppRouter;
