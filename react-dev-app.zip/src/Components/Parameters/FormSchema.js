export const parameterSchema = {
  name: 'parameters',
  fields: [
    {
      name: 'name',
      type: 'text',
      modelType: 'string',
      label: 'Select Type',
      class: 'field-col-12',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'type',
      type: 'select',
      modelType: 'string',
      label: 'Select Type',
      class: 'field-col-12',
      options: [
        { value: '', label: '---- Select ----' },
        {
          optgroup: true, label: 'List', children: [
            { value: '1', label: 'Single Select' },
            { value: '2', label: 'Multi Select' }
          ]
        },
        { value: '3', label: 'Boolean' }
      ],
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'paramValues',
      type: 'array',
      label: 'Manage Values',
      class: 'field-col-12',
      fields: [
        {
          name: 'name',
          type: 'text',
          modelType: 'string',
          label: 'Select Type',
          class: 'field-col-12',
          validators: [
            {
              type: 'required'
            }
          ]
        }
      ]
    }
  ]
};