import {
  Box, Typography, Button, Grid, TextField, FormControl, InputLabel, Select, FormHelperText
} from '@mui/material';
import { notificationActions } from '../../Store/notification';
import { Formik, FieldArray, getIn } from 'formik';
import * as Yup from 'yup';
import { useSelector, useDispatch } from 'react-redux';
import { parameterSchema } from './FormSchema';
import DynamicForm from '../Common/DynamicForm';

function Parameters() {
  const dispatch = useDispatch();
  const initialValues = {
    name: '',
    type: '',
    paramValues: [],
    sort: 0,
    visibility: '1'
  };
  // const validationSchema = Yup.object().shape({
  //   name: Yup.string().required('This field is required'),
  //   type: Yup.string().required('This field is required'),
  //   paramValues: Yup.array().of(
  //     Yup.object().shape({
  //       value: Yup.string().required('This field is required'),
  //     })
  //   )
  // });

  // const CreateErrorText = ({ errors, touched, index }) => {
  //   let errMsg = null, isTouched = false;
  //   isTouched = getIn(touched, `paramValues.${index}.value`);
  //   errMsg = getIn(errors, `paramValues.${index}.value`);
  //   return (isTouched && errMsg) ? errMsg : null;
  // }

  // const checkIfDuplicateParamValues = (paramValues) => {
  //   const listOfAllParamValues = paramValues.map(param => param.value);
  //   const hasDuplicateValues = listOfAllParamValues.filter((item, index) => listOfAllParamValues.indexOf(item) !== index)
  //   console.log(hasDuplicateValues);

  //   return hasDuplicateValues;
  // }

  const onUpdateFieldValue = (e) => {
    const { name, value } = e.target;
  }

  const handleOnSubmit = (values) => {
    // if (checkIfDuplicateParamValues(values.paramValues)) {
    //   dispatch(notificationActions.showNotification({ type: 'error', message: 'Duplicate parameter values' }));
    // } else {

    // }
  };

  return (
    <Box sx={{ marginTop: 2 }}>
      <Typography variant="h4">Manage Parameters</Typography>
      <Grid container display="flex" flexDirection="row">
        <Grid sx={{ width: '40%' }} item>
          <DynamicForm
            schema={parameterSchema}
            initialValues={initialValues}
            getFieldsOnBlur={onUpdateFieldValue}
            onSubmitForm={handleOnSubmit}
          />
          {/* <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {({ values, errors, touched, handleSubmit, handleChange, resetForm }) => (
              <form onSubmit={handleSubmit} noValidate>
                <TextField
                  autoFocus
                  id="name"
                  label="Name"
                  fullWidth
                  variant="standard"
                  name="name"
                  value={values.name}
                  onChange={handleChange}
                  error={!!(touched.name && errors.name)}
                  helperText={(touched.name && errors.name) && errors.name}
                />
                <FormControl sx={{ mt: 2 }} variant="standard" fullWidth error={!!(touched.type && errors.type)}>
                  <InputLabel id="type">Select Type</InputLabel>
                  <Select native value={values.type} name="type" id="type" onChange={handleChange}>
                    <option value=""></option>
                    <optgroup label="List">
                      <option value="1">Single Select</option>
                      <option value="2">Multi Select</option>
                    </optgroup>
                    <option value="3">Boolean</option>
                  </Select>
                  <FormHelperText>{(touched.type && errors.type) && errors.type}</FormHelperText>
                </FormControl>
                <FieldArray name="paramValues">
                  {({ push, remove }) => (
                    <Box sx={{ mt: 2 }}>
                      <Button type="button" variant="contained" size="small" onClick={() => push({ value: '' })}>Add Parameter Values</Button>
                      {values.paramValues.map((param, index) =>
                        <Grid key={index} display="flex">
                          <TextField
                            id={`paramValues.${index}.value`}
                            label="Parameter Value"
                            fullWidth
                            variant="standard"
                            name={`paramValues.${index}.value`}
                            onChange={handleChange}
                            error={!!(CreateErrorText({ errors, touched, index }))}
                            helperText={<CreateErrorText errors={errors} touched={touched} index={index} />}
                          />
                          <Button onClick={() => remove(index)}>X</Button>
                        </Grid>
                      )}
                    </Box>
                  )}
                </FieldArray>

                <Grid sx={{ mt: 2 }} item xs={12} md={12} display="flex" flexDirection="row" justifyContent="flex-start" alignItems="center">
                  <Grid item sx={{ mr: 2 }}>
                    <Button type="button" variant="contained" color="warning" sx={{ mb: 2 }}>Cancel</Button>
                  </Grid>
                  <Grid item>
                    <Button type="submit" variant="contained" color="primary" sx={{ mb: 2 }}>Submit</Button>
                  </Grid>
                </Grid>
              </form>
            )}
          </Formik> */}
        </Grid>
        <Grid sx={{ width: '60%' }} item></Grid>
      </Grid>
    </Box>
  );
}

export default Parameters;
