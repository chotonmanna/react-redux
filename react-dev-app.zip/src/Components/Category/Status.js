import {
  Grid, FormControlLabel, FormLabel,
  RadioGroup, Radio
} from '@mui/material';
import FormControl from '@mui/material/FormControl';
import { useNavigate, useOutletContext } from 'react-router-dom';

function Status() {
  const { formikProps } = useOutletContext();
  const { values, errors, touched, handleChange, handleBlur, handleSubmit, resetForm } = formikProps;
  return (
    <Grid sx={{ mt: 2 }} item xs={12} md={12}>
      <FormControl>
        <FormLabel>Status</FormLabel>
        <RadioGroup row name="status" value={values.status} onChange={handleChange}>
          <FormControlLabel label="Active" value='1' control={<Radio />} />
          <FormControlLabel label="Inactive" value='0' control={<Radio />} />
        </RadioGroup>
      </FormControl>
    </Grid>
  );
}

export default Status; 