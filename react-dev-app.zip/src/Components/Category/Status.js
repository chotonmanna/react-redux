import { useNavigate, useOutletContext } from 'react-router-dom';
import { statusSchema } from '../Category/FormSchema';
import { useDispatch } from 'react-redux';
import DynamicForm from '../Common/DynamicForm';
import {submitCategoryData} from '../../Store/category/category-actions';

function Status() {
  const { onUpdateFieldValue, category } = useOutletContext();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const initialValues = {
    status: category?.status || '0'
  };

  // const handleResetForm = (resetForm) => {
  //   resetForm();
  //   dispatch(categoryActions.resetEdiatbleData());
  // }

  const handleOnSubmit = async () => {
    const response = await dispatch(submitCategoryData(category));
    if (!response?.error) {
      navigate('/category');
    }
  }

  return (
    <DynamicForm
      schema={statusSchema}
      initialValues={initialValues}
      getFieldsOnChange={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default Status; 