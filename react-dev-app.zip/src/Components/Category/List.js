import { useSelector, useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { getAllList } from '../../Store/category/category-actions';
import { categoryActions } from '../../Store/category/category-slice';

const CategoryList = () => {
  const list = useSelector(state => state.category.list);
  const dataAsEditable = useSelector(state => state.category.data);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getAllList());
  }, [dispatch]);

  const editThisData = (row) => {
    dispatch(categoryActions.setDataAsEdiatble(row));
  }

  const DisplayCategoryTree = ({ list }) => {
    return (
      list.map((row, key) =>
        <li key={key}>
          <a onClick={() => editThisData(row)} className={[
            dataAsEditable?.id === row.id && 'editable',
            row.status === '0' && 'inactive',
          ].join(' ')}>{row.name}</a>
          {(row?.children && row.children.length) && <ul><DisplayCategoryTree list={row.children} /></ul>}
        </li>
      )
    );
  }

  return (
    list.length ?
      <ul><DisplayCategoryTree list={list} /></ul>
      : null
  );
};

export default CategoryList;