import { useSelector, useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { getAllList } from '../../Store/category/category-actions';

const CategoryList = () => {
  const list = useSelector(state => state.category.list);
  const category = useSelector(state => state.category.data);
  const dispatch = useDispatch();

  useEffect(() => {
    const getList = async () => {
      await dispatch(getAllList());
    }
    getList();
  }, [dispatch]);

  const editThisData = async (cateId) => {
    await dispatch(getAllList(cateId));
  }

  const getCategoryClass = (row) => {
    const classNames = [];

    if (row.status === '0') {
      classNames.push('inactive');
    }

    if (category?.id === row.id) {
      classNames.push('editable');
    }

    return classNames.join(' ');
  }

  const DisplayCategoryTree = ({ list }) => {
    return (
      list.map((row, key) =>
        <li key={key}>
          <a onClick={() => editThisData(row.id)} className={getCategoryClass(row)}>{row.name}</a>
          {(row?.children && row.children.length) && <ul><DisplayCategoryTree list={row.children} /></ul>}
        </li>
      )
    );
  }

  return (
    list.length ?
      <ul><DisplayCategoryTree list={list} /></ul>
      : null
  );
};

export default CategoryList;