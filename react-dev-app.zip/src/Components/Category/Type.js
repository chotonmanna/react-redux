import { Grid, MenuItem, FormHelperText, InputLabel, FormControl, Select, Box } from '@mui/material';
import { useNavigate, useOutletContext } from 'react-router-dom';
import * as Yup from 'yup';
import { Formik } from 'formik';
import { useSelector } from 'react-redux';
import { StepperButtons } from '../Common/FormStepper/StepperButtons';

function Type() {
  const { onInputChangeHandler } = useOutletContext();
  const category = useSelector(state => state.category.data);

  const navigate = useNavigate();
  const initialValues = {
    type: category?.type || ''
  };

  const validationSchema = Yup.object().shape({
    type: Yup.string().oneOf(['1', '2'], 'This field is required')
  });

  const onSubmit = () => {
    navigate('/category/details');
  }

  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ values, errors, touched, handleChange, handleSubmit }) => (
        <Box sx={{ marginTop: 2 }}>
          <form onSubmit={handleSubmit} noValidate>
            <Grid sx={{ mt: 2 }} item xs={10} md={10}>
              <FormControl variant="standard" fullWidth error={!!(touched.type && errors.type)}>
                <InputLabel id="type">Select Type</InputLabel>
                <Select name="type" id="type" value={values.type} onChange={(e) => onInputChangeHandler(e, handleChange)}>
                  <MenuItem value="">---- Select Type -----</MenuItem>
                  <MenuItem value="1">Product Page</MenuItem>
                  <MenuItem value="2">Static Content Page</MenuItem>
                </Select>
                <FormHelperText>{(touched.type && errors.type) && errors.type}</FormHelperText>
              </FormControl>
              <StepperButtons id="category" />
            </Grid>
          </form>
        </Box>
      )}
    </Formik>
  );
}

export default Type; 