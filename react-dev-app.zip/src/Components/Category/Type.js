import { useNavigate, useOutletContext } from 'react-router-dom';
import { typeSchema } from '../Category/FormSchema';
import DynamicForm from '../Common/DynamicForm';

function Type() {
  const { onUpdateFieldValue, category } = useOutletContext();

  const navigate = useNavigate();
  const initialValues = {
    type: category?.type || ''
  };

  const handleOnSubmit = () => {
    navigate('/category/details');
  }

  return (
    <DynamicForm
      schema={typeSchema}
      initialValues={initialValues}
      getFieldsOnChange={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default Type; 