import {
  Grid, TextField, MenuItem
} from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Fragment, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate, useOutletContext } from 'react-router-dom';

function Details() {
  const { formikProps } = useOutletContext();
  const { values, errors, touched, handleChange, handleBlur, handleSubmit, resetForm } = formikProps;
  const list = useSelector(state => state.category.list);
  const modifiedList = useMemo(() => {
    const arr = [];
    const makeArray = (list, spaces = 0) => {
      list.forEach(row => {
        spaces = row?.parent === '0' ? 0 : spaces;
        arr.push({ ...row, spaces });
        if (row?.children && row.children.length) {
          makeArray(row?.children, spaces + 4);
        }
      });
    }
    makeArray(list);

    return arr;
  }, [list]);

  return (
    <Fragment>
      <Grid sx={{ mt: 2 }} item xs={10} md={10}>
        <FormControl variant="standard" fullWidth>
          <InputLabel id="parent">Select Menu</InputLabel>
          <Select name="parent" id="parent" value={values.parent} onChange={handleChange}>
            <MenuItem value={0}><em>Root</em></MenuItem>
            {
              modifiedList.map((row, key) =>
                <MenuItem key={key} value={row.id}>
                  {Array(row.spaces).fill().map((r, k) => <Fragment key={k}>&nbsp;</Fragment>)}
                  {row.name}
                </MenuItem>)
            }
          </Select>
        </FormControl>
      </Grid>

      <Grid item xs={10} md={10}>
        <TextField
          variant="standard"
          name="name"
          required
          fullWidth
          id="name"
          label="Menu Name"
          value={values.name}
          onChange={handleChange}
          onBlur={handleBlur}
          error={!!(touched.name && errors.name)}
          helperText={(touched.name && errors.name) && errors.name}
        />
      </Grid>
    </Fragment>
  );
}

export default Details; 