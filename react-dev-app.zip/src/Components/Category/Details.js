import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { detailsSchema } from '../Category/FormSchema';
import DynamicForm from '../Common/DynamicForm';
import { createListOptionsForMultiLevel } from '../../Config';
import { updateOptionsList } from '../Common/DynamicForm/SchemaHelper';

function Details() {
  const [schemaValue, setSchemaValue] = useState(detailsSchema);
  const { onUpdateFieldValue, category } = useOutletContext();

  const list = useSelector(state => state.category.list);
  const navigate = useNavigate();
  const initialValues = {
    parent: category?.parent || '0',
    name: category?.name || '',
  };

  useEffect(() => {
    if (list.length) {
      const options = createListOptionsForMultiLevel(list);
      setSchemaValue(updateOptionsList('parent', (prevOptions) => {
        prevOptions.push.apply(prevOptions, options);
        return prevOptions;
      }));
    }
  }, [list]);

  const handleOnSubmit = () => {
    navigate('/category/others');
  }

  return (
    <DynamicForm
      schema={schemaValue}
      initialValues={initialValues}
      getFieldsOnBlur={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default Details; 