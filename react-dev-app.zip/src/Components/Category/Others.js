import { useNavigate, useOutletContext } from 'react-router-dom';
import { othersSchema } from '../Category/FormSchema';
import DynamicForm from '../Common/DynamicForm';

function Others() {
  const { onUpdateFieldValue, category } = useOutletContext();

  const navigate = useNavigate();
  const initialValues = {
    isNew: category?.isNew || '0',
    isSale: category?.isSale || '0'
  };

  const handleOnSubmit = () => {
    navigate('/category/status');
  }

  return (
    <DynamicForm
      schema={othersSchema}
      initialValues={initialValues}
      getFieldsOnChange={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default Others; 