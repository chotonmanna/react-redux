import {
  Grid, FormControlLabel, FormLabel,
  RadioGroup, Radio
} from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Fragment, useMemo } from 'react';
import { useNavigate, useOutletContext } from 'react-router-dom';

function Others() {
  const { formikProps } = useOutletContext();
  const { values, errors, touched, handleChange, handleBlur, handleSubmit, resetForm } = formikProps;
  return (
    <Fragment>
      <Grid sx={{ mt: 2 }} item xs={12} md={6}>
        <FormControl>
          <FormLabel>Is New ?</FormLabel>
          <RadioGroup row name="isNew" value={values.isNew} onChange={handleChange}>
            <FormControlLabel label="Yes" value='1' control={<Radio />} />
            <FormControlLabel label="No" value='0' control={<Radio />} />
          </RadioGroup>
        </FormControl>
      </Grid>

      <Grid sx={{ mt: 2 }} item xs={12} md={5}>
        <FormControl>
          <FormLabel>Is Sale ?</FormLabel>
          <RadioGroup row name="isSale" value={values.isSale} onChange={handleChange}>
            <FormControlLabel label="Yes" value='1' control={<Radio />} />
            <FormControlLabel label="No" value='0' control={<Radio />} />
          </RadioGroup>
        </FormControl>
      </Grid>
    </Fragment>
  );
}

export default Others; 