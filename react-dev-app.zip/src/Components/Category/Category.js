import {
  Box, Typography, Grid
} from '@mui/material';

import CategoryList from './List';
import { useSelector, useDispatch } from 'react-redux';
import { updateData } from '../../Store/category/category-actions';

import './Category.css';
import { categoryActions } from '../../Store/category/category-slice';
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import FormStepper from '../Common/FormStepper';
import { StepperButtons } from '../Common/FormStepper/StepperButtons';
import { getCurrentRoute } from '../../Config';
import { useMemo } from 'react';

function Category() {
  const navigate = useNavigate();
  const location = useLocation();
  //const { isStartStep, isEndStep, prevPath, nextPath } = useMemo(() => getCurrentRoute('category', location.pathname), [location]);
  const category = useSelector(state => state.category.data);
  const dispatch = useDispatch();
  // const initialValues = {
  //   parent: dataAsEditable?.parent || '0',
  //   name: dataAsEditable?.name || '',
  //   status: dataAsEditable?.status || '1',
  //   type: dataAsEditable?.type || '0',
  //   isNew: dataAsEditable?.isNew || '0',
  //   isSale: dataAsEditable?.isSale || '0'
  // };

  // const onSubmit = (values, { resetForm }) => {
  //   console.log(isEndStep);
  //   if (isEndStep) {
  //     console.log('end tep');
  //   } else {
  //     navigate(nextPath);
  //   }
  //   // const updatedValue = { ...dataAsEditable, ...values };
  //   // dispatch(updateData(updatedValue, () => {
  //   //   handleResetForm(resetForm);
  //   // }));
  // }

  // const handleResetForm = (resetForm) => {
  //   resetForm();
  //   dispatch(categoryActions.resetEdiatbleData());
  // }

  const onInputChangeHandler = (e, handleChange) => {
    const { name, value } = e.target;
    dispatch(categoryActions.updateData({ ...category, [name]: value }));
    handleChange(e);
    // if (debouncedTimeout) clearTimeout(debouncedTimeout);
    // debouncedTimeout = setTimeout(() => dispatch(registrationActions.updateData({ ...user, [name]: value })), 500);
  }

  return (
    <Box sx={{ marginTop: 2 }}>
      <Typography variant="h4">Manage Menus</Typography>
      <Grid container display="flex" flexDirection="row">
        <Grid sx={{ width: '65%' }} item>
          <Grid container>
            {JSON.stringify(category)}
            <FormStepper id="category">
              <Outlet context={{ onInputChangeHandler }} />
            </FormStepper>
          </Grid>
        </Grid>
        <Grid sx={{ width: '35%' }} item>
          <CategoryList />
        </Grid>
      </Grid>
    </Box>
  );
}

export default Category;
