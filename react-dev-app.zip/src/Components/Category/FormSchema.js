export const typeSchema = {
  name: 'categoryType',
  fields: [
    {
      name: 'type',
      type: 'select',
      modelType: 'string',
      label: 'Select Type',
      class: 'field-col-12',
      options: [
        { value: '', label: '--- Select ---' },
        { value: '1', label: 'Product Page' },
        { value: '2', label: 'Static Content Page' }
      ],
      validators: [
        {
          type: 'required'
        },
        {
          type: 'oneOf',
          values: ['1', '2'],
          message: 'Not a valid selection'
        }
      ]
    }
  ]
};

export const detailsSchema = {
  name: 'categoryDetails',
  fields: [
    {
      name: 'parent',
      type: 'select',
      modelType: 'string',
      label: 'Select Menu',
      class: 'field-col-12',
      options: [
        { value: '', label: '--- Select ---' },
        { value: '0', label: 'Root' }
      ],
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'name',
      type: 'text',
      modelType: 'string',
      label: 'Menu Name',
      class: 'field-col-12',
      validators: [
        {
          type: 'required'
        }
      ]
    }
  ]
};

export const othersSchema = {
  name: 'categoryOthers',
  fields: [
    {
      name: 'isNew',
      type: 'radio',
      modelType: 'string',
      label: 'Is New ?',
      class: 'field-col-6',
      options: [
        { value: '1', label: 'Yes' },
        { value: '0', label: 'No' }
      ],
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'isSale',
      type: 'radio',
      modelType: 'string',
      label: 'Is Sale ?',
      class: 'field-col-6',
      options: [
        { value: '1', label: 'Yes' },
        { value: '0', label: 'No' }
      ],
      validators: [
        {
          type: 'required'
        }
      ]
    }
  ]
};

export const statusSchema = {
  name: 'categoryStatus',
  fields: [
    {
      name: 'status',
      type: 'radio',
      modelType: 'string',
      label: 'Status',
      class: 'field-col-6',
      options: [
        { value: '1', label: 'Active' },
        { value: '0', label: 'Inactive' }
      ],
      validators: [
        {
          type: 'required'
        }
      ]
    }
  ]
};