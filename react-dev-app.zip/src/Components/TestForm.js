import DynamicForm from '../Components/Common/DynamicForm';
/**
 * inputType: text, textarea, select, select (multiple), password, checkbox, radio, email, object, array, hidden
 * modelType: string, number, boolean
 */
//const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/

export default function TestForm() {
  const initialValues = {
    firstName: '',
    secondName: '',
    email: '',
    gender: '',
    hobby: ['D', 'S'],
    termsCondition: true,
    address: {
      city: '',
      state: '',
      lane: [{
        no1: '11',
        no2: '22'
      }]
    },
    cars: [
      {
        name: 'Hyundai',
        model: 'i10 nios'
      },
      {
        name: 'Maruti',
        model: 'Alto k10'
      }
    ]
  };

  const formSchema = {
    name: 'testForm',
    fields: [
      {
        name: 'firstName',
        type: 'text',
        modelType: 'string',
        label: 'First Name',
        validators: [
          {
            type: 'required',
            message: 'Please enter your first name'
          }
        ]
      },
      {
        name: 'secondName',
        type: 'text',
        label: 'Second Name',
        modelType: 'string',
        validators: [
          {
            type: 'required',
            message: 'Please enter your second name'
          },
          // {
          //   type: 'email',
          //   message: 'Please enter your second name'
          // },
          {
            type: 'min',
            length: 6,
            message: 'Minimum 6 length'
          },
          {
            type: 'max',
            length: 10,
            message: 'Maximum 10 length'
          },
          // {
          //   type: 'matches',
          //   pattern: phoneRegExp,
          //   message: 'Invalid pattern matches'
          // },
          // {
          //   type: 'isTrue',
          //   message: 'Please select terms condition'
          // },
          // {
          //   type: 'oneOf',
          //   values: ['1', '2'],
          //   message: 'This field is required'
          // },
          {
            type: 'oneOf',
            ref: 'firstName',
            message: 'First Name & Second Name must be same'
          }
        ]
      },
      {
        name: 'email',
        type: 'text',
        modelType: 'string',
        label: 'Email Id',
        validators: [
          {
            type: 'required',
            message: 'Please enter your email id'
          },
          {
            type: 'email',
            message: 'Invalid email'
          }
        ]
      },
      {
        name: 'address',
        type: 'object',
        label: 'Address',
        fields: [
          {
            name: 'city',
            type: 'text',
            label: 'City',
            modelType: 'string',
            validators: [
              {
                type: 'required',
                message: 'Please enter your city'
              }
            ]
          },
          {
            name: 'state',
            type: 'text',
            label: 'State',
            modelType: 'string',
            validators: [
              {
                type: 'required',
                message: 'Please enter your state'
              }
            ]
          },
          {
            name: 'lane',
            type: 'array',
            label: 'Lane',
            fields: [
              {
                name: 'no1',
                type: 'text',
                label: 'No 1',
                modelType: 'string',
                validators: [
                  {
                    type: 'required',
                    message: 'Please enter your first lane'
                  }
                ]
              },
              {
                name: 'no2',
                type: 'text',
                label: 'No 2',
                modelType: 'string',
                validators: [
                  {
                    type: 'required',
                    message: 'Please enter your second lane'
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        name: 'gender',
        type: 'select',
        label: 'Gender',
        modelType: 'string',
        options: [
          { value: '', label: '--- Select ---' },
          { value: 'M', label: 'Male' },
          { value: 'F', label: 'Female' }
        ],
        validators: [
          {
            type: 'required'
          },
          {
            type: 'oneOf',
            values: ['M', 'F'],
            message: 'Not a valid selection'
          }
        ]
      },
      {
        name: 'hobby',
        type: 'checkbox',
        label: 'Hobby',
        modelType: 'array',
        options: [
          { value: 'F', label: 'Football' },
          { value: 'C', label: 'Cricket' },
          { value: 'S', label: 'Swimming' },
          { value: 'D', label: 'Driving' }
        ]
      },
      {
        name: 'termsCondition',
        type: 'checkbox',
        label: 'Agreed terms & conditions',
        modelType: 'boolean'
      },
      {
        name: 'cars',
        type: 'array',
        label: 'Cars',
        fields: [
          {
            name: 'name',
            type: 'text',
            label: 'Name',
            modelType: 'string'
          },
          {
            name: 'model',
            type: 'text',
            label: 'Model',
            modelType: 'string'
          }
        ]
      }
    ]
  };
  //console.log(modifyJsonSchema(formSchema));
  const handleOnChange = (props) => {
    //console.log(22, props);
    const { e } = props;
    //setSubmitting(true);
    console.log(e.target.name, e.target.value);

    //if (e.target.name === 'firstName' && e.target.value === 'Biswajit') {
    // setValues({
    //   secondName: 'Manna',
    //   gender: 'M',
    //   address: 'Salkia'
    // });
    // setFieldValue('secondName', 'Manna');
    // setFieldValue('gender', 'M');
    // setFieldValue('address', 'Salkia');
    //formSchema.fields[1].value = 'Manna';
    //formSchema.fields[1].disabled = true;
    //}

    //formSchema.fields[1].disabled = 'Manna';
  }

  const handleOnSubmit = (values, props) => {
    console.log(values, props);
  }

  const handleOnReset = (values, props) => {
    console.log(values, props);
  }

  //const obj = {
  // method: () => {
  //   return {
  //     test: () => {
  //       return {
  //         test1: () => {
  //           console.log('New Hello World');
  //         }
  //       }
  //     }
  //   }
  // }
  //};

  // const obj = {
  //   method1: (test) => {
  //     console.log('method1');
  //     return obj;
  //   },
  //   method2: () => {
  //     console.log('method2');
  //     return obj;
  //   },
  //   method3: () => {
  //     console.log('method3');
  //     return obj;
  //   }
  // }

  // obj.method1('okk').method2().method3();

  // obj['method'] = () => {
  //   console.log('New Hello World');
  // }


  return (
    <div>
      <DynamicForm
        schema={formSchema}
        initialValues={initialValues}
        onUpdateFields={handleOnChange}
        onSubmitForm={handleOnSubmit}
        onResetForm={handleOnReset}
      />
    </div>
  );
}