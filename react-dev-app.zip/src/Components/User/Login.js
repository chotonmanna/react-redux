import { Box, Avatar, Typography } from '@mui/material';
import { useEffect } from 'react';
import { useCookie } from '../../Hooks/useCookie';
import { useSelector, useDispatch } from 'react-redux';
import { submitLoginData } from '../../Store/login/login-actions';
import { useNavigate } from 'react-router-dom';
import { userLoginSchema } from './FormSchema';
import DynamicForm from '../Common/DynamicForm';

function Login() {
  const [setRememberMeUserCookieValue, rememberMeUserCookieValue] = useCookie('rememberMeUser');
  const authUserData = useSelector(state => state.login.authUserData);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const initialValues = {
    username: rememberMeUserCookieValue?.username || '',
    password: rememberMeUserCookieValue?.password || '',
    rememberMe: rememberMeUserCookieValue?.rememberMe || false
  };

  useEffect(() => {
    if (authUserData) {
      navigate('/profile');
    }
  }, [authUserData, navigate]);

  const handleOnSubmit = async (values) => {
    const response = await dispatch(submitLoginData(values));
    if (!response?.error && response?.payload) {
      setRememberMeUserCookieValue(values.rememberMe ? JSON.stringify(values) : null);
    }
  }

  return (
    <Box sx={{ marginTop: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}></Avatar>
      <Typography variant="h4">Sign In</Typography>
      <DynamicForm
        schema={userLoginSchema}
        initialValues={initialValues}
        onSubmitForm={handleOnSubmit}
      />
    </Box>
  );
}

export default Login;