import { useNavigate, useOutletContext } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { addressDetailsSchema } from '../FormSchema';
import DynamicForm from '../../Common/DynamicForm';

function AddressDetails() {
  const { onUpdateFieldValue } = useOutletContext();
  const navigate = useNavigate();
  const user = useSelector(state => state.registration.data);
  const initialValues = {
    houseNumber: user?.houseNumber || '',
    land1: user?.land1 || '',
    land2: user?.land2 || '',
    zipcode: user?.zipcode || '',
    city: user?.city || '',
    state: user?.state || '',
    country: user?.country || ''
  };

  const handleOnSubmit = () => {
    navigate('/registration/login-details');
  }

  return (
    <DynamicForm
      schema={addressDetailsSchema}
      initialValues={initialValues}
      getFieldsOnBlur={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default AddressDetails;