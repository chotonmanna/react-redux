import { useOutletContext } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { submitUserData } from '../../../Store/registration/registration-actions';
import { loginDetailsSchema } from '../FormSchema';
import DynamicForm from '../../Common/DynamicForm';

function LoginDetails() {
  const { onUpdateFieldValue } = useOutletContext();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector(state => state.registration.data);
  const initialValues = {
    username: user?.username || '',
    password: user?.password || '',
    confirmPassword: user?.confirmPassword || '',
    termsCondition: user?.termsCondition || false
  };

  const handleOnSubmit = async () => {
    const response = await dispatch(submitUserData(user));
    if (!response?.error) {
      navigate('/registration');
    }
  }

  return (
    <DynamicForm
      schema={loginDetailsSchema}
      initialValues={initialValues}
      getFieldsOnBlur={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default LoginDetails;