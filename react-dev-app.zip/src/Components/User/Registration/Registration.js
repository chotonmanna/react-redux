import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { Outlet } from "react-router-dom";
import FormStepper from '../../Common/FormStepper';
import { useDispatch, useSelector } from 'react-redux';
import { registrationActions } from '../../../Store/registration/registration-slice';
import { Translate } from '../../Common/Translate';

export default function Registration() {
  //let debouncedTimeout;
  const dispatch = useDispatch();
  const user = useSelector(state => state.registration.data);
  const onInputChangeHandler = (e, handleChange) => {
    const { name, value } = e.target;
    dispatch(registrationActions.updateData({ ...user, [name]: value }));
    handleChange(e);
    // if (debouncedTimeout) clearTimeout(debouncedTimeout);
    // debouncedTimeout = setTimeout(() => dispatch(registrationActions.updateData({ ...user, [name]: value })), 500);
  }

  return (
    <Box
      sx={{
        marginTop: 8,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}
    >
      <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}></Avatar>
      <Typography variant="h4"><Translate labelKey="registration.heading" type="html" params={{ fname: 'Biswajit', lname: 'Manna' }} /></Typography>
      <FormStepper id="registration">
        <Outlet context={{ onInputChangeHandler }} />
      </FormStepper>
    </Box>
  );
}
