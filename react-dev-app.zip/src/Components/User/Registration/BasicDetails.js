
import { useNavigate, useOutletContext } from 'react-router-dom';
import { useSelector } from 'react-redux';
import DynamicForm from '../../Common/DynamicForm';
import { basicDetailsSchema } from '../FormSchema';

function BasicDetails() {
  const { onUpdateFieldValue } = useOutletContext();
  const user = useSelector(state => state.registration.data);

  const navigate = useNavigate();
  const initialValues = {
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    mobile: user?.mobile || '',
    dob: user?.dob || '',
    gender: user?.gender || ''
  };

  const handleOnSubmit = () => {
    navigate('/registration/address-details');
  }

  return (
    <DynamicForm
      schema={basicDetailsSchema}
      initialValues={initialValues}
      getFieldsOnBlur={onUpdateFieldValue}
      onSubmitForm={handleOnSubmit}
    />
  );
}

export default BasicDetails;