import { Box, Typography } from '@mui/material';
//import { useAuthContext } from '../Common/Auth';

function Profile() {
  //const auth = useAuthContext();
  return (
    <Box sx={{ marginTop: 8}}>
      <Typography variant="h4">My Profile</Typography>
      {/* <button onClick={auth.logout}>Logout</button> */}
    </Box>
  );
}

export default Profile;
