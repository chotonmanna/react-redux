const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/

export const basicDetailsSchema = {
  name: 'basicDetails',
  fields: [
    {
      name: 'firstName',
      type: 'text',
      modelType: 'string',
      label: 'First Name',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'lastName',
      type: 'text',
      modelType: 'string',
      label: 'Last Name',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'email',
      type: 'email',
      modelType: 'string',
      label: 'Email ID',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        },
        {
          type: 'email',
          message: 'Invalid email'
        }
      ]
    },
    {
      name: 'dob',
      type: 'text',
      modelType: 'string',
      label: 'Date of birth',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        },
        // {
        //   type: 'test',
        //   name: 'is-valid-dob',
        //   message: 'Must be a valid dateof birth',
        //   method: (value) => {
        //     if (value.length === 10 && value.includes('-')) {
        //       const spltdob = value.split('-');
        //       if (spltdob[0].length === 4 && spltdob[1].length === 2 && spltdob[2].length == 2) {
        //         //if (parseInt(spltdob[0].length))
        //         console.log(typeof spltdob[0]);
        //       }  
        //     }

        //     return false;
        //   }
        // }
      ]
    },
    {
      name: 'mobile',
      type: 'text',
      modelType: 'string',
      label: 'Mobile number',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        },
        {
          type: 'matches',
          pattern: phoneRegExp,
          message: 'Phone number is not valid'
        }
      ]
    },
    {
      name: 'gender',
      type: 'radio',
      modelType: 'string',
      label: 'Gender',
      class: 'field-col-6',
      options: [
        { value: 'M', label: 'Male' },
        { value: 'F', label: 'Female' }
      ],
      validators: [
        {
          type: 'required'
        }
      ]
    }
  ]
};

export const addressDetailsSchema = {
  name: 'addressDetails',
  fields: [
    {
      name: 'houseNumber',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.house-number',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'land1',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.land1',
      class: 'field-col-12',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'land2',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.land2',
      class: 'field-col-12'
    },
    {
      name: 'zipcode',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.zip',
      class: 'field-col-6',
      validators: [
        { type: 'required' },
        {
          type: 'min',
          length: 6,
          message: 'Must be 6 chars length'
        },
        {
          type: 'max',
          length: 6,
          message: 'Must be 6 chars length'
        },
        {
          type: 'matches',
          pattern: /[0-9]{6}/,
          message: 'Not a valid zipcode'
        }
      ]
    },
    {
      name: 'city',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.city',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'state',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.state',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'country',
      type: 'text',
      modelType: 'string',
      label: 'registration.address-details.country',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        }
      ]
    }
  ]
};

export const loginDetailsSchema = {
  name: 'loginDetails',
  fields: [
    {
      name: 'username',
      type: 'text',
      modelType: 'string',
      label: 'registration.login-details.username',
      class: 'field-col-12',
      validators: [
        {
          type: 'required'
        },
        {
          type: 'min',
          length: 6,
          message: 'Must be 6 chars length'
        }
      ]
    },
    {
      name: 'password',
      type: 'password',
      modelType: 'string',
      label: 'registration.login-details.password',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        },
        {
          type: 'min',
          length: 6,
          message: 'Must be 6 chars length'
        }
      ]
    },
    {
      name: 'confirmPassword',
      type: 'password',
      modelType: 'string',
      label: 'registration.login-details.conf-password',
      class: 'field-col-6',
      validators: [
        {
          type: 'required'
        },
        {
          type: 'oneOf',
          ref: 'password',
          message: 'Confirm password must match passord'
        }
      ]
    },
    {
      name: 'termsCondition',
      type: 'checkbox',
      modelType: 'boolean',
      label: 'registration.login-details.terms-conditions',
      class: 'field-col-6',
      validators: [
        {
          type: 'isTrue',
          message: 'Please select terms condition'
        }
      ]
    }
  ]
};

export const userLoginSchema = {
  name: 'userLogin',
  fields: [
    {
      name: 'username',
      type: 'text',
      modelType: 'string',
      label: 'registration.login-details.username',
      class: 'field-col-12',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'password',
      type: 'password',
      modelType: 'string',
      label: 'registration.login-details.password',
      class: 'field-col-12',
      validators: [
        {
          type: 'required'
        }
      ]
    },
    {
      name: 'rememberMe',
      type: 'checkbox',
      modelType: 'boolean',
      label: 'Remember Me',
      class: 'field-col-6'
    }
  ]
}; 