import { Field } from 'formik';
import { useContext } from 'react';
import { DynamicFormContext } from '../index';

export const Textbox = (props) => {
  const { field } = props;
  const { formikProps, onInputChangeHandler, onInputBlurHandler } = useContext(DynamicFormContext);

  return <Field
    type={field.type || 'text'}
    id={field.name}
    name={field.name}
    disabled={field?.disabled || false}
    className="input-control"
    onChange={(event) => onInputChangeHandler( event, formikProps )}
    onBlur={(event) => onInputBlurHandler( event, formikProps )}
  />
}