import { Field } from 'formik';
import { useContext } from 'react';
import { DynamicFormContext } from '../index';

export const Textarea = (props) => {
  const { field } = props;
  const { formikProps, onInputChangeHandler, onInputBlurHandler } = useContext(DynamicFormContext);

  return <Field
    as="textarea"
    id={field.name}
    name={field.name}
    className="input-control"
    onChange={(event) => onInputChangeHandler( event, formikProps )}
    onBlur={(event) => onInputBlurHandler( event, formikProps )}
  />
}