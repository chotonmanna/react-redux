import { FormField } from '../FormField';

export const InputObject = (props) => {
  const { field } = props;

  return field.fields.map((subField, index) =>
    <FormField
      key={index}
      field={{ ...subField, name: `${field.name}.${subField.name}` }}
    />
  )
};