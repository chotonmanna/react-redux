import { Field } from 'formik';
import { useContext } from 'react';
import { DynamicFormContext } from '../index';

export const Select = (props) => {
  const { field } = props;
  const { formikProps, onInputChangeHandler, onInputBlurHandler } = useContext(DynamicFormContext);

  const RenderOptionList = ({ options }) => {
    return options?.map((option, index) =>
      option?.optgroup ?
        <optgroup key={index} label={option.label}>
          <RenderOptionList options={option?.children || []} />
        </optgroup> :
        <RenderOption key={index} option={option} />
    )
  }

  const RenderOption = ({ option }) => {
    return <option value={option.value} dangerouslySetInnerHTML={{ __html: option.label }}>
    </option>;
  }

  return <Field
    id={field.name}
    name={field.name}
    as="select"
    className="input-control"
    onChange={(event) => onInputChangeHandler( event, formikProps )}
    onBlur={(event) => onInputBlurHandler( event, formikProps )}
  >
    <RenderOptionList options={field?.options || []} />
  </Field>
}

/**
 * [
 *   {value: '11', label: 'QQ'},
 *   {optgroup: true, label: 'List', children: [
 *    {value: '11', label: 'Single Select'},
 *    {value: '11', label: 'Multi Select'}
 *   ] },
 *   {value: '22', label: 'WW'}
 * ]
 */