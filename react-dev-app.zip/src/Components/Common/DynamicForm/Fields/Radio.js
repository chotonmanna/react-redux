import { Field } from 'formik';
import { useContext } from 'react';
import { DynamicFormContext } from '../index';

export const Radio = (props) => {
  const { field } = props;
  const { formikProps, onInputChangeHandler, onInputBlurHandler } = useContext(DynamicFormContext);

  return <div>
    {field.options.map((option, index) =>
      <label key={index}> <Field
        type="radio"
        name={field.name}
        value={option.value}
        onChange={(event) => onInputChangeHandler( event, formikProps )}
        onBlur={(event) => onInputBlurHandler( event, formikProps )}
      /> {option.label}
      </label>
    )}
  </div>
}