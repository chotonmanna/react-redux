import { FieldArray, getIn } from 'formik';
import { InputObject } from './index';
import { useContext, useMemo } from 'react';
import { DynamicFormContext } from '../index';

export const InputArray = (props) => {
  const { field } = props;
  const { formikProps } = useContext(DynamicFormContext);
  const fieldValue = useMemo(() => getIn(formikProps.values, field.name) || [], [formikProps.values, field.name]);
  const handleClickOnAdd = (push, fields) => {
    const keys = {};
    fields.forEach(element => {
      keys[element.name] = '';
    });
    push(keys);
  }

  return <FieldArray name={field.name}>
    {({ remove, push }) => (
      <fieldset className={field.name}>
        {fieldValue.length > 0 &&
          fieldValue.map((value, index) => (
            <div className="row" key={index}>
              <InputObject key={index} field={{ ...field, name: `${field.name}.${index}` }} />
              <div className="col">
                <button type="button" onClick={() => remove(index)}>X</button>
              </div>
            </div>
          ))}
        <button type="button" onClick={() => handleClickOnAdd(push, field.fields)}>Add Car</button>
      </fieldset>
    )}
  </FieldArray>
}