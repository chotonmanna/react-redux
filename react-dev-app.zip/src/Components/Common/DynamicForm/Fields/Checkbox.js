import { Field } from 'formik';
import { useContext } from 'react';
import { DynamicFormContext } from '../index';
import { Translate } from '../../Translate';

export const Checkbox = (props) => {
  const { field } = props;
  const { formikProps, onInputChangeHandler } = useContext(DynamicFormContext);

  return <div>
    {!field.options && <label>
      <Field
        type="checkbox"
        name={field.name}
        onChange={(event) => onInputChangeHandler( event, formikProps )} />
      <Translate labelKey={field.label} />
    </label>
    }

    {field.options && field.options.map((option, index) =>
      <label key={index}>
        <Field
          type="checkbox"
          name={field.name}
          value={option.value}
          onChange={(event) => onInputChangeHandler( event, formikProps )} />
        <Translate labelKey={option.label} />
      </label>
    )}
  </div>
}