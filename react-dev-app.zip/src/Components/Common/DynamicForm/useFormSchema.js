import { useState, useCallback } from 'react';
const nonEditableProps = ['name', 'type', 'modelType'];

export const useFormSchema = (schema) => {
  const [schemaValue, setSchemaValue] = useState(schema);

  const updateSchemaProps = useCallback(
    (fieldName, propsName, propsValue) => {
      console.log('updateSchemaProps');
      if (nonEditableProps.includes(propsName)) {
        console.warn(`${propsName} can not be editable`);
        return;
      }
      const updatedFields = schemaValue.fields.map(field => {
        if (field.name === fieldName) {
          if (typeof propsValue === 'function') {
            field[propsName] = propsValue(field[propsName]);
          } else {
            field[propsName] = propsValue;
          }

        }
        return field;
      });

      setSchemaValue(prevSchema => {
        return {
          ...prevSchema,
          fields: updatedFields
        }
      });
    },
    [schemaValue]
  );

  return [schemaValue, updateSchemaProps];
}