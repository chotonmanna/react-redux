import { InputArray, InputObject, Checkbox, Radio, Select, Textarea, Textbox } from './Fields';

export const FieldInput = (props) => {
  const { field } = props;
  let fieldElement;

  switch (field.type) {
    case 'array':
      fieldElement = <InputArray field={field} />
      break;
    case 'object':
      fieldElement = <InputObject field={field} />
      break;
    case 'select':
      fieldElement = <Select field={field} />
      break;
    case 'radio':
      fieldElement = <Radio field={field} />
      break;
    case 'checkbox':
      fieldElement = <Checkbox field={field} />
      break;
    case 'textarea':
      fieldElement = <Textarea field={field} />
      break;
    default:
      fieldElement = <Textbox field={field} />
      break;
  }
  return fieldElement;
}