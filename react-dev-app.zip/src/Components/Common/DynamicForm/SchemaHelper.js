let schema = null;

export const setSchema = (updatedSchema) => {
  schema = updatedSchema;
}

export const updateOptionsList = (fieldName, optionValues) => {
  return {
    ...schema,
    fields: schema.fields.map(field => {
      if (field.name === fieldName) {
        if (typeof optionValues === 'function') {
          field.options = optionValues(field.options);
        } else {
          field.options = optionValues;
        }
      }
      return field;
    })
  };
}

