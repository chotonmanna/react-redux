import * as Yup from 'yup';

export const getValidators = (field) => {
  if (field?.validators) {
    return generateValidationSchema(field);
  } else if (field.type === 'array') {
    return Yup.array().of(getValidatorsObject(field));
  } else if (field.type === 'object') {
    return getValidatorsObject(field);
  }
}

const getValidatorsObject = (field) => {
  const validators = {};
  field.fields.forEach(subField => {
    validators[subField.name] = getValidators(subField);
  });
  return Yup.object().shape(validators);
}

const generateValidationSchema = (field) => {
  let validationSchema = Yup[field.modelType]();
  field.validators.forEach(validator => {
    if (!validationSchema[validator.type]) {
      return validationSchema;
    }

    switch (validator.type) {
      case "min":
      case "max":
        validationSchema = validationSchema[validator.type](validator.length, validator.message);
        break;
      case "matches":
        validationSchema = validationSchema[validator.type](validator.pattern, validator.message);
        break;
      case "oneOf":
        validationSchema = validator?.ref ?
          validationSchema[validator.type]([Yup.ref(validator.ref)], validator.message) :
          validationSchema[validator.type](validator.values, validator.message);
        break;
      case 'test':
        validationSchema = validationSchema[validator.type](validator.name, validator.message, validator.method);
        break;
      default:
        validationSchema = validationSchema[validator.type](validator?.message || 'This field is required');
        break;
    }
  });

  return validationSchema;
}
