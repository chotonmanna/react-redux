import { useMemo, createContext, useEffect } from 'react';
import { Formik, getIn } from 'formik';
import * as Yup from 'yup';
import { getValidators } from './utils';
import { FormField } from './FormField';
import { setSchema } from './SchemaHelper';
import './style.css';

export const DynamicFormContext = createContext();

export default function DynamicForm(props) {

  const { initialValues, schema, getFieldsOnChange, getFieldsOnBlur, onSubmitForm, onResetForm, showReset } = props;
  useEffect(() => {
    setSchema(schema);
  }, [schema]);

  const validationSchema = useMemo(() => {
    const validators = {};
    schema.fields.forEach(field => {
      validators[field.name] = getValidators(field);
    });
    return Yup.object().shape(validators);
  }, [schema]);

  const onInputChangeHandler = (event, props) => {
    const { handleChange } = props;
    handleChange(event);
    getFieldsOnChange && getFieldsOnChange(event, props);
  }

  const onInputBlurHandler = (event, props) => {
    const { handleBlur } = props;
    handleBlur(event);
    getFieldsOnBlur && getFieldsOnBlur(event, props);
  }

  const getClassName = (formikProps, field) => {
    const classNames = [field.name, field.class, 'field-control'];
    const error = getIn(formikProps.errors, field.name);
    const touch = getIn(formikProps.touched, field.name);
    if (error && touch) {
      classNames.push('error-control');
    }

    return classNames.join(' ');
  }

  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmitForm}
      onReset={onResetForm}
    >
      {(formikProps) => (
        <form
          name={schema.name}
          onSubmit={formikProps.handleSubmit}
          onReset={formikProps.resetForm} noValidate>
          <div className="fields-container">
            <DynamicFormContext.Provider value={{
              formikProps, onInputChangeHandler, onInputBlurHandler, getClassName
            }}>
              {schema.fields.map((field, index) =>
                <FormField
                  key={index}
                  field={field}
                />
              )}
            </DynamicFormContext.Provider>
          </div>
          <div className="buttons-container">
            {showReset && <button className="reset-btn" type="reset" >Reset</button>}
            <button className="submit-btn" type="submit" disabled={props.isSubmitting}>Submit</button>
          </div>
        </form>
      )}
    </Formik>
  );
}