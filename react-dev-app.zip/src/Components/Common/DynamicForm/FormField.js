import { FieldInput } from './FieldInput';
import { ErrorMessage } from 'formik';
import { useContext } from 'react';
import { DynamicFormContext } from './index';
import { Translate } from '../Translate';

export const FormField = (props) => {
  const { field } = props;
  const { formikProps, getClassName } = useContext(DynamicFormContext);

  return <div className={getClassName(formikProps, field)}>
    {field.label && <label htmlFor={field.name}><Translate labelKey={field.label} /></label>}
    <FieldInput field={field} />
    {field?.validators?.length && <ErrorMessage name={field.name} component="div" className="error-message" />}
  </div>
}