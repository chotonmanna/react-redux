import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import { useSelector, useDispatch } from 'react-redux';
import { loginActions } from '../../Store/login/login-slice';
import { useNavigate } from "react-router-dom";
import { LanguageSelector, Translate } from './Translate';

const pages = [
  { path: 'category', menu: 'Category' },
  { path: 'manage-parameters', menu: 'Parameters' },
  { path: 'manage-products', menu: 'Products' }
];

function RecatAppBar() {
  const authUserData = useSelector(state => state.login.authUserData);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const logout = () => {
    dispatch(loginActions.logout());
    navigate('/login');
  }

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <Typography
            variant="h6"
            noWrap
            component="a"
            href="/"
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            LOGO
          </Typography>
          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {pages.map((page, key) => (
              <Button
                onClick={() => navigate(page.path)}
                key={key}
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                {page.menu}
              </Button>
            ))}
          </Box>
          {authUserData &&
            <Box sx={{ flexGrow: 0 }} display="flex" flexDirection="row" alignItems="end">
              <Button sx={{ my: 2, color: 'white', display: 'block' }}>
                <Translate labelKey="top-bar.welcome-name" params={{ name: authUserData.name }} />
              </Button>
              <Button onClick={logout} sx={{ my: 2, color: 'white', display: 'block' }}>
                <Translate labelKey="top-bar.logout" />
              </Button>
            </Box>
          }

          {!authUserData &&
            <Box sx={{ flexGrow: 0 }} display="flex" flexDirection="row" alignItems="end">
              <Button onClick={() => navigate('/registration')} sx={{ my: 2, color: 'white', display: 'block' }}>
                <Translate labelKey="top-bar.sign-up" />
              </Button>
              <Button onClick={() => navigate('/login')} sx={{ my: 2, color: 'white', display: 'block' }}>
                <Translate labelKey="top-bar.sign-in" />
              </Button>
            </Box>
          }
          <LanguageSelector />
        </Toolbar>
      </Container>
    </AppBar>
  );
}
export default RecatAppBar;