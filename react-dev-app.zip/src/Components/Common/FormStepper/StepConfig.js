import { AddressDetails, BasicDetails, LoginDetails } from '../../User/Registration';
import { Details, Type, Status, Others } from '../../Category';

export const steps = [
  {
    id: 'registration',
    path: 'registration',
    children: [
      {
        path: 'basic-details',
        label: 'registration.steps.basic-details',
        component: <BasicDetails />
      },
      {
        path: 'address-details',
        label: 'registration.steps.address-details',
        component: <AddressDetails />
      },
      {
        path: 'login-details',
        label: 'registration.steps.login-details',
        component: <LoginDetails />
      }
    ]
  },
  {
    id: 'category',
    path: 'category',
    children: [
      {
        path: 'type',
        label: 'Type',
        component: <Type />
      },
      {
        path: 'details',
        label: 'Details',
        component: <Details />
      },
      {
        path: 'others',
        label: 'Others',
        component: <Others />
      },
      {
        path: 'status',
        label: 'Status',
        component: <Status />
      }
    ]
  }
];
