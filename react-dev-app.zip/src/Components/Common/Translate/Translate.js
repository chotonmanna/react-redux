import { Fragment, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { langStorage } from '../../../Store/i18n/lang-config';

export default function Translate({ labelKey, type = 'text', params = null }) {
  const currentLanguage = useSelector(state => state.i18n.currentLanguage);
  const translatedText = useMemo(() => {
    const data = langStorage[currentLanguage];
    if (!data[labelKey]) {
      return labelKey;
    }

    if (!params) {
      return data[labelKey];
    }

    if (params) {
      let text = data[labelKey];
      for (const key in params) {
        if (params.hasOwnProperty(key)) {
          const element = params[key];
          text = text.replaceAll(`{{${key}}}`, element);
        }
      }
      return text;
    }

  }, [currentLanguage, labelKey, params]);

  return (
    type === 'text'
      ? <Fragment>{translatedText}</Fragment>
      : <span dangerouslySetInnerHTML={{ __html: translatedText }}></span>
  );
}
