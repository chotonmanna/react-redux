import { createSlice } from '@reduxjs/toolkit';
import { submitLoginData } from './login-actions';
import { persistReducer } from 'redux-persist';
import { CookieStorage } from 'redux-persist-cookie-storage';
import Cookies from 'cookies-js';

const loginSlice = createSlice({
  name: 'login',
  initialState: {
    authUserData: null
  },
  reducers: {
    logout(state) {
      state.authUserData = null
    }
  },
  extraReducers: {
    [submitLoginData.fulfilled]: (state, action) => {
      state.authUserData = action.payload;
    },
    [submitLoginData.rejected]: (state) => {
      state.authUserData = null;
    }
  }
});

export const loginActions = loginSlice.actions;

const reducer = persistReducer({
  key: 'login-persisit',
  storage: new CookieStorage(Cookies)
}, loginSlice.reducer);

export default reducer;