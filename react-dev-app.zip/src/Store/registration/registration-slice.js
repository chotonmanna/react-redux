import { createSlice } from '@reduxjs/toolkit';
import { submitUserData } from "./registration-actions";
import { persistReducer } from 'redux-persist';
import storageSession from 'redux-persist/lib/storage/session';

const initialState = {
  data: {}
};

const registrationSlice = createSlice({
  name: 'registration',
  initialState,
  reducers: {
    updateData(state, action) {
      state.data = { ...state.data, ...action.payload };
    }
  },
  extraReducers: (builder) => {
    builder.addCase(submitUserData.fulfilled, (state) => {
      state.data = {};
    })
  }
});

export const registrationActions = registrationSlice.actions;

const reducer = persistReducer({
  key: 'registration-persist',
  storage: storageSession
}, registrationSlice.reducer);

export default reducer;