import { createSlice } from '@reduxjs/toolkit';
import { submitUserData } from "./registration-actions";
import storageSession from 'redux-persist/lib/storage/session';
import { persistReducer } from 'redux-persist';

const initialState = {
  data: {}
};

const registrationSlice = createSlice({
  name: 'registration',
  initialState,
  reducers: {
    updateData(state, action) {
      state.data = { ...state.data, ...action.payload };
    }
  },
  extraReducers: {
    [submitUserData.fulfilled]: (state) => void (state.data = {})
  }
});

export const registrationActions = registrationSlice.actions;

const reducer = persistReducer({
  key: 'registration-persist',
  storage: storageSession
}, registrationSlice.reducer);

export default reducer;