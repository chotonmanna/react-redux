import axios from "axios";
import { notificationActions } from '../notification';
import { getConfig } from '../../Config';
import { createAsyncThunk } from '@reduxjs/toolkit';

export const submitUserData = createAsyncThunk('user/submitdata', async (data, { rejectWithValue, dispatch }) => {
  dispatch(notificationActions.showSpinner());
  try {
    const response = await axios.post(`${getConfig().baseUrl}/user/registration`, data);
    dispatch(notificationActions.hideSpinner());
    if (response?.data) {
      dispatch(notificationActions.showNotification({ type: 'success', message: response.data.msg }));
      return response.data?.data;
    }
  } catch (error) {
    const message = error?.response?.data?.msg || 'Unable to login.. Try later';
    dispatch(notificationActions.showNotification({ type: 'error', message }));
    dispatch(notificationActions.hideSpinner());
    return rejectWithValue(message);
  }
});
