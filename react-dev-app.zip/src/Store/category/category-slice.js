import { createSlice } from '@reduxjs/toolkit';
import { submitCategoryData } from './category-actions';
import { persistReducer } from 'redux-persist';
import storageSession from 'redux-persist/lib/storage/session';

const categorySlice = createSlice({
  name: 'category',
  initialState: {
    list: [],
    data: {}
  },
  reducers: {
    updateData(state, action) {
      state.data = { ...state.data, ...action.payload };
    },
    updateList(state, action) {
      state.list = action.payload;
    },
    setDataAsEdiatble(state, action) {
      state.data = action.payload;
    },
    resetEdiatbleData(state) {
      state.data = null;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(submitCategoryData.fulfilled, (state) => {
      state.data = {};
    })
  }
});

export const categoryActions = categorySlice.actions;

const reducer = persistReducer({
  key: 'category-persist',
  storage: storageSession,
  blacklist: ['list']
}, categorySlice.reducer);

export default reducer;