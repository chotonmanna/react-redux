import axios from "axios";
import { notificationActions } from '../notification';
import { categoryActions } from './category-slice';
import { getConfig } from '../../Config';
import { createAsyncThunk } from '@reduxjs/toolkit';

export const getAllList = createAsyncThunk('category/getlist', async (cateId = null, { dispatch, rejectWithValue }) => {
  dispatch(notificationActions.showSpinner());
  try {
    let url = 'category/getalllist';
    if (cateId) {
      url = `${url}?cateId=${cateId}`;
    }

    const response = await axios.get(`${getConfig().baseUrl}/${url}`);
    dispatch(notificationActions.hideSpinner());

    if (cateId) {
      dispatch(categoryActions.setDataAsEdiatble(response.data.data));
    } else {
      dispatch(categoryActions.updateList(response.data.data));
    }

    return response.data?.data;
  } catch (error) {
    const message = error?.response?.data?.msg || 'Unable to login.. Try later';
    dispatch(notificationActions.showNotification({ type: 'error', message }));
    dispatch(notificationActions.hideSpinner());
    return rejectWithValue(message);
  }
});


export const submitCategoryData = createAsyncThunk('category/submitdata', async (data, { dispatch, rejectWithValue }) => {
  dispatch(notificationActions.showSpinner());
  try {
    let response = null;
    if (data?.id) {
      response = await axios.put(`${getConfig().baseUrl}/category/update`, data);
    } else {
      response = await axios.post(`${getConfig().baseUrl}/category/addnew`, data);
    }

    dispatch(notificationActions.hideSpinner());
    dispatch(notificationActions.showNotification({ type: 'success', message: response.data.msg }));
    if (response.data) {
      dispatch(categoryActions.updateList(response.data.data));
      return response.data?.data;
    }
  } catch (error) {
    const message = error?.response?.data?.msg || 'Unable to login.. Try later';
    dispatch(notificationActions.showNotification({ type: 'error', message }));
    dispatch(notificationActions.hideSpinner());
    return rejectWithValue(message);
  }
});
