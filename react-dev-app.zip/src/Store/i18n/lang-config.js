const config = {
  default: 'en',
  languages: [
    { id: 'en', label: 'EN' },
    { id: 'fr', label: 'FR' }
  ]
}

const convertNestedObjectToPlain = (data, object, concatString = '') => {
  for (const key in object) {
    if (object.hasOwnProperty(key)) {
      const element = object[key];
      if (typeof element === 'string') {
        data[`${concatString}${key}`] = element;
      } else {
        convertNestedObjectToPlain(data, element, `${concatString}${key}.`)
      }
    }
  }

  return data;
}

const langStorage = {};
config.languages.forEach(lang => {
  const loadedLanguage = require(`./lang/${lang.id}.json`);
  const data = {};
  langStorage[lang.id] = convertNestedObjectToPlain(data, loadedLanguage);
});

export {
  langStorage,
  config
}