import { configureStore, combineReducers } from '@reduxjs/toolkit';
import registrationReducer from './registration/registration-slice';
import loginReducer from './login/login-slice';
import notificationSlice from './notification';
import categoryReducer from './category/category-slice';
import translateSliceReducer from './i18n/translate-slice';
import { PERSIST } from 'redux-persist';

const store = configureStore({
  reducer: combineReducers({
    registration: registrationReducer,
    notification: notificationSlice.reducer,
    login: loginReducer,
    category: categoryReducer,
    i18n: translateSliceReducer
  }),
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [PERSIST],
      },
    }),
});

export default store;
