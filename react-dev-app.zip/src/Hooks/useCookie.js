import Cookies from 'universal-cookie';
import { useState } from 'react';

export const useCookie = (name, defaultValue = null) => {
  const cookies = new Cookies();
  const [cookieValue, setValue] = useState(() => {
    if (cookies.get(name)) {
      return cookies.get(name);
    }

    return defaultValue;
  });

  const setCookieValue = (newValue) => {
    if (!newValue) {
      cookies.remove(name);
    } else {
      cookies.set(name, newValue);
    }
    setValue(newValue);
  }

  return [setCookieValue, cookieValue];
}
